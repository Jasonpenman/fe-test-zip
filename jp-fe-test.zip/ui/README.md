# arqiva-fe-test

A small ui for the Arqiva fe test.
Uses vue 3, vite, pinia and tailwind for styling.

Jason Penman

## Make sure you have the api running before launching

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```

### Run Unit Tests with [Vitest](https://vitest.dev/)

```sh
npm run test:unit
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```
