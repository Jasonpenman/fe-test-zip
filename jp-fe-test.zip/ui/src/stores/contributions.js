import { ref, nextTick } from 'vue';
import { defineStore } from 'pinia';
import { useRouter } from 'vue-router';

export const useContributionStore = defineStore('contribution', () => {
  const router = useRouter();
  const maxPages = ref(1);
  const contributions = ref([]);
  const pageNumber = ref(1);
  const searchValue = ref('');

  const apiUrl = 'http://localhost:8000/';
  const filterTerms = ['title', 'description', 'owner', 'startTime', 'endTime'];

  const createFilters = (filters) => {
    getContributions(filters);
  };

  const updateQueryParams = async (params) => {
    const urlParams = router.currentRoute.value.query;
    const existingParams = urlParams.params ? new URLSearchParams(urlParams.params) : new URLSearchParams();
    const hasFilter = !!filterTerms.find(key => params.has(key))

    if (hasFilter) filterTerms.map(key => existingParams.delete(key));
    existingParams.forEach((value, key) => {
      if (!params.has(key)) {
        params.append(key, value);
      }
    });

    const searchString = filterTerms.find(term => params.has(term))
    searchValue.value = searchString ? params.get(searchString) : '';

    return params;
  };

  const getContributions = async (options = '?limit=14&skip=0') => {
    const endpoint = 'contributions/';
    const inputParams = new URLSearchParams(options);

    await getTotalContributions();
    await nextTick();

    const params = await updateQueryParams(inputParams);
    router.push({ query: { params: params.toString() } });

    pageNumber.value = params.get('skip') ? Math.ceil(params.get('skip') / 14) + 1 : 1;

    const response = await fetch(`${apiUrl}${endpoint}?${params.toString()}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });

    contributions.value = await response.json();
    maxPages.value = Math.ceil(contributions.value.total / 14);
  };

  const getTotalContributions = async () => {
    const response = await fetch(`${apiUrl}totalContributions/`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      }
    });

    const data = await response.json();
    maxPages.value = Math.ceil(data.total / 14);
  };

  const resetPage = () => {
    pageNumber.value = 1;
    searchValue.value = '';
    nextTick();
    router.push({ query: {} });
    getContributions();
  };

  return {
    contributions,
    maxPages,
    filterTerms,
    pageNumber,
    searchValue,
    getContributions,
    createFilters,
    resetPage
  };
});
