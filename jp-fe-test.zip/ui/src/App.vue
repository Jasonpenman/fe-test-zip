<script setup>
import { ref, onMounted } from 'vue'
import { storeToRefs } from 'pinia'
import { useContributionStore } from './stores/contributions'
import ContributorList from './components/ContributorList.vue'

const store = useContributionStore()
const { contributions } = storeToRefs(store)
const maxPages = storeToRefs(store).maxPages
const filterObj = ref({ skip: 0, limit: 14 })

const handleSortAction = (sortType) => {
  filterObj.value = { ...filterObj.value.skip, ...sortType }
  store.createFilters(filterObj.value)
}

const reset = () => store.resetPage()

onMounted(() => {
  store.createFilters()
})
</script>

<template>
  <div class="container">
    <button class="text-sm text-center font-bold text-gray-700 my-4"
    @click="reset"
    aria-label="Reset Button">Reset Page</button>
    <ContributorList
      :contributorsList="contributions.contributions"
      @handleAction="handleSortAction"
      :maxPages="maxPages"
      v-if="contributions.contributions"
    />
  </div>
</template>
<style>
html {
  display: flex;
  justify-content: center;
}
body {
  background-color: #f4f5f7;
  max-width: 1280px;
  display: grid;
  align-items: center;
  padding: 0 3rem;
}
@media screen and (max-width: 768px) {
  body {
    padding: 0 .4rem;
  }
  
}
</style>
