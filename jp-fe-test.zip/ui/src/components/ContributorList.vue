<script setup>
import ContributionHeader from './ContributionHeader.vue'
import ContributorSingle from './ContributorSingle.vue'

const props = defineProps(['contributorsList', 'maxPages'])
const emit = defineEmits(['handleAction'])

const performSearch = (searchTerm) => {
  emit('handleAction', searchTerm)
}
</script>

<template>
  <ContributionHeader @handleAction="performSearch" :maxPages="maxPages" />

  <div
    v-if="contributorsList.length"
    class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 px-8 mb-20"
  >
    <ContributorSingle
      v-for="contributor in contributorsList"
      :key="contributor.id"
      :contribution="contributor"
    />
  </div>

  <div v-else>
    <h3 class="text-center mt-20">No contributions found</h3>
  </div>
</template>
