<script setup>
const props = defineProps(['contribution'])

const dateFormatter = (date) => {
  return `${new Date(date).toLocaleTimeString()} 
    ${new Date(date).toLocaleDateString()}`
}

const getStatus = (contribution) => {
  const now = new Date()
  return new Date(contribution.endTime) < now
    ? 'Complete'
    : new Date(contribution.endTime) > now
    && new Date(contribution.startTime) < now
      ? 'Active'
      : 'Scheduled'
}

const statusColor = (contribution) => {
  const status = getStatus(contribution)
  return status === 'Complete'
    ? 'border border-red-500 shadow-lg'
    : status === 'Active'
      ? 'border border-green-500 bg-green-100 shadow-lg'
      : 'border border-yellow-500 bg-yellow-100 shadow-lg'
}

</script>
<template>
  <article :class="statusColor(contribution)" class="p-6 animate" role="region" aria-labelledby="contribution-title">
    <h3 id="contribution-title" class="text-lg text-gray-700 font-bold text-center">{{ contribution.title }}</h3>
    <p class="text-center py-4 text-gray-600">{{ contribution.description }}</p>
    <div class="grid grid-cols-1 sm:flex w-100 place-content-between my-2">
      <span class="w-100 font-bold">Start Time:</span>
      <span aria-label="Start time">{{ dateFormatter(contribution.startTime) }}</span>
    </div>
    <div class="grid grid-cols-1 sm:flex w-100 place-content-between my-2">
      <span class="w-100 font-bold">End Time:</span>
      <span aria-label="End time">{{ dateFormatter(contribution.endTime) }}</span>
    </div>
    <div class="grid grid-cols-1 sm:flex w-100 place-content-between my-2">
      <span class="w-100 font-bold">Contributor:</span>
      <p aria-label="Contributor">{{ contribution.owner }}</p>
    </div>
    <div class="grid grid-cols-1 sm:flex w-100 place-content-between my-2">
      <span class="w-100 font-bold">Status:</span>
      <p aria-label="Status">{{ getStatus(contribution) }}</p>
    </div>
  </article>
</template>

<style scoped>
.animate {
  animation: fadeIn 0.5s;
}
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: scale(0);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}
</style>