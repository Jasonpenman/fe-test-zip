<script setup>
import { ref, onMounted } from 'vue'
import { storeToRefs } from 'pinia'
import { useContributionStore } from '../stores/contributions'
const emit = defineEmits(['search', 'sort', 'handleAction'])
const props = defineProps(['maxPages', 'resetPage'])

const store = useContributionStore()
const pageNumber = storeToRefs(store).pageNumber
const urlSearchValue = storeToRefs(store).searchValue
const searchTerm = ref('')
const selectedFilter = ref('title')

const search = () => emit('handleAction', { [selectedFilter.value]: searchTerm.value, skip: 0 })

const disablePrevious = () => (pageNumber.value === 1 ? 'disabled' : '')
const disableNext = () => (pageNumber.value === props.maxPages ? 'disabled' : '')

const searchOptions = [
  { value: 'title', label: 'Title' },
  { value: 'description', label: 'Description' },
  { value: 'owner', label: 'Owner' },
  { value: 'startTime', label: 'Start Time' },
  { value: 'endTime', label: 'End Time' },
]

const setPage = (page) => {
  if (page === 0) {
    if (pageNumber.value === 1) return
    pageNumber.value = pageNumber.value - 1
  } else {
    if (pageNumber.value === props.maxPages) return
    pageNumber.value = pageNumber.value + 1
  }
  const skipValue = (pageNumber.value - 1) * 14
  emit('handleAction', { skip: skipValue })
}
onMounted(() => {
  searchTerm.value = urlSearchValue.value
})

</script>

<template>
 <div
  class="w-100 px-4 py-4 my-4 bg-stone-300 grid sm:grid-cols-2 grid-cols-1 align-middle shadow-lg"
  role="search" aria-label="Search Contributions"
>
  <div class="grid grid-cols-1 xl:grid-cols-2 gap-2 w-100 sm:ml-0 mx-auto sm:mr-auto">
    <div class="flex">
      <div class="flex">
        <label for="search-input" class="sr-only">Search</label>
        <input
          type="text"
          id="search-input"
          class="inline-block p-1 rounded"
          placeholder="Search..."
          @keyup.enter="search"
          v-model="searchTerm"
          aria-label="Search input"
        />
        <input
          type="button"
          id="search-button"
          class="inline-block text-white bg-gray-600 px-2 py-1 ml-2 rounded"
          @click="search"
          value="Search"
          aria-label="Search button"
        />
      </div>
    </div>

    <div class="justify-start mx-auto mt-1 sm:ml-0 inline-block" v-if="searchTerm.length">
      <label for="filter-select" class="inline text-sm">Filter by</label>
      <select
        v-if="selectedFilter"
        id="filter-select"
        class="inline-block text-sm ml-2 p-1 rounded"
        v-model="selectedFilter"
        aria-label="Filter select"
      >
        <option v-for="option in searchOptions" :key="option.value" :value="option.value">
          {{ option.label }}
        </option>
      </select>
    </div>
  </div>

  <div class="text-center mt-6 sm:mt-0 mx-auto md:mr-0 md:ml-auto flex self-center" role="navigation" aria-label="Pagination">
    <input
      type="button"
      :class="disablePrevious()"
      class="inline-block w-8 h-8 text-white bg-gray-600 px-2 py-1 ml-2 rounded"
      @click="setPage(0)"
      value="-"
      aria-label="Previous page"
      :disabled="disablePrevious() === 'disabled'"
    />
    <p class="inline ml-2 mt-1">Page {{ pageNumber }} of {{ maxPages }}</p>
    <input
      type="button"
      :class="disableNext()"
      class="inline-block w-8 h-8 text-white bg-gray-600 px-2 py-1 ml-2 rounded"
      @click="setPage(1)"
      value="+"
      aria-label="Next page"
      :disabled="disableNext() === 'disabled'"
    />
  </div>
</div>

</template>

<style scoped>
.disabled {
  cursor: not-allowed;
  opacity: 0.5;
}
</style>
