import { shallowMount } from '@vue/test-utils';
import { describe, it, expect, beforeEach } from 'vitest'
import ContributionList from '../ContributorList.vue'
import ContributionHeader from '@/components/ContributionHeader.vue'; // Adjust the import to your file structure
import ContributorSingle from '@/components/ContributorSingle.vue'; // Adjust the import to your file structure

describe('ContributionList.vue', () => {
  let wrapper;
  const contributorsList = [
    { id: 1, name: 'Contributor 1' },
    { id: 2, name: 'Contributor 2' }
  ];
  const maxPages = 3;

  beforeEach(() => {
    wrapper = shallowMount(ContributionList, {
      propsData: { contributorsList, maxPages }
    }); 
  });

  it('renders ContributionHeader with correct props', () => {
    const header = wrapper.findComponent(ContributionHeader);
    expect(header.exists()).toBe(true);
    expect(header.props().maxPages).toBe(maxPages);
  });

  it('renders ContributorSingle for each contributor', () => {
    const contributors = wrapper.findAllComponents(ContributorSingle);
    expect(contributors).toHaveLength(contributorsList.length);
    contributorsList.forEach((contributor, index) => {
      expect(contributors.at(index).props().contribution).toEqual(contributor);
    });
  });

  it('emits handleAction when performSearch is called', async () => {
    const searchTerm = 'test search';
    await wrapper.vm.performSearch(searchTerm);
    expect(wrapper.emitted().handleAction).toBeTruthy();
    expect(wrapper.emitted().handleAction[0]).toEqual([searchTerm]);
  });

  it('shows message when no contributors found', async () => {
    await wrapper.setProps({ contributorsList: [] });
    const message = wrapper.find('h3');
    expect(message.exists()).toBe(true);
    expect(message.text()).toBe('No contributions found');
  });
});
