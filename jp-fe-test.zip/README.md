# Arqiva fe-test
Note, I was unable to run FastApi on windows, as a workaround i used a fresh linux install.
I created a simple front end to display the api data, search and search with filters working. 
It could use some more polishing, resetting the search input, getting the amount of search 
results and various small improvements

The front end is using vue 3 with pinia, vite and tailwind. I didnt make it very pretty


## Steps to run,
clone repo, 

cd into server/

## Installation
 
`pip install -r requirements.txt`
(only needed if not previously installed) 

## Running the server

`fastapi dev main.py`

## Running the front end
open a fresh terminal,

'cd ../ui/'

'npm i'

then when complete 
'npm run dev'
